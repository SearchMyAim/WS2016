const homeModel = {
    title: "Startseite"
};

module.exports = homeModel;